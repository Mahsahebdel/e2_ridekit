import numpy as np
import pandas as pd


df = pd.read_csv('original_dataset.csv')

print("The size of the dataset is: ", df.info)